﻿using Nest;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessLibrary.Models
{
    public class CardioLog
    {

		#region Constructors 
		
		public CardioLog()
		{

		}

		public CardioLog(int id, string logName, DateTime logDate, string cardioType, TimeSpan startTime, TimeSpan endTime, int caloriesBurned)
		{
			ClientId = id;
			LogName = logName;
			LogDate = logDate;
			StartTime = startTime;
			EndTime = endTime;
			CaloriesBurned = caloriesBurned;
			CardioType = cardioType;
		}

		public CardioLog(CardioLog instance)
			: this(instance.ClientId, instance.LogName, instance.LogDate, instance.CardioType, instance.StartTime, instance.EndTime, instance.CaloriesBurned)
		{
		}

		#endregion

		#region Properties

		[JsonProperty(PropertyName = "clientId")]
		public int ClientId { get; set; }

		[JsonProperty(PropertyName = "logName")]
		public string LogName;

		[JsonProperty(PropertyName = "logDate")]
		public DateTime LogDate { get; set; }

		[JsonProperty(PropertyName = "startTime")]
		public TimeSpan StartTime { get; set; }

		[JsonProperty(PropertyName = "endTime")]
		public TimeSpan EndTime { get; set; }

		[JsonProperty(PropertyName = "caloriesBurned")]
		public int CaloriesBurned { get; set; }

		[JsonProperty(PropertyName = "cardioType")]
		public string CardioType { get; set; }

		#endregion
	}
}
