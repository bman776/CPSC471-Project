﻿using Nest;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessLibrary.Models
{
	public class Page
	{
		#region Constructors
		public Page()
		{
		}

		public Page(int id, string topic, string content, string author, DateTime writeDate, int viewCount)
		{
			Id = id;
			Topic = topic;
			Content = content;
			Author = author;
			WriteDate = writeDate;
			ViewCount = viewCount;
		}

		public Page(Page instance)
			: this(instance.Id, instance.Topic, instance.Content, instance.Author, instance.WriteDate, instance.ViewCount)
		{
		}

		#endregion

		#region Properties
		[JsonProperty(PropertyName = "id")]
		public int Id { get; set; }

		[JsonProperty(PropertyName = "topic")]
		public string Topic { get; set; }

		[JsonProperty(PropertyName = "content")]
		public string Content { get; set; }

		[JsonProperty(PropertyName = "author")]
		public string Author { get; set; }

		[JsonProperty(PropertyName = "writeDate")]
		public DateTime WriteDate { get; set; }

		[JsonProperty(PropertyName = "viewCount")]
		public int ViewCount { get; set; }

		#endregion

		#region Methods

		#endregion
	}
}
