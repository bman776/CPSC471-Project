﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using BusinessLibrary.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using Webservice.ContextHelpers;
using Webservice.ControllerHelpers;

namespace Webservice.Controllers
{
    [Route("api/nutritionPlans")]
    [ApiController]
    public class NutritionPlanController : ControllerBase
    {

        #region Initialization

        /// <summary>
        /// Reference to the hosting environment instance added in the Startup.cs.
        /// </summary>
        private readonly IHostingEnvironment HostingEnvironment;

        /// <summary>
        /// Reference to the app settings helper instance added in the Startup.cs.
        /// </summary>
        private readonly AppSettingsHelper AppSettings;

        /// <summary>
        /// Reference to the database context helper instance added in the Startup.cs.
        /// </summary>
        private readonly DatabaseContextHelper Database;

        /// <summary>
        /// Constructor called by the service provider.
        /// Using injection to get the arguments.
        /// </summary>
        public NutritionPlanController(IHostingEnvironment hostingEnvironment, AppSettingsHelper appSettings,
            DatabaseContextHelper database)
        {
            HostingEnvironment = hostingEnvironment;
            AppSettings = appSettings;
            Database = database;
        }

        #endregion


        // Gets collection.
        [HttpGet]
        [Route("GetNutritionPlans")]
        public ResponseMessage GetNutritionPlans([FromBody] JObject data)
        {
            var response = NutritionPlanHelper.GetCollection(data,
                context: Database.DbContext,
                statusCode: out HttpStatusCode statusCode,
                includeDetailedErrors: HostingEnvironment.IsDevelopment());
            HttpContext.Response.StatusCode = (int)statusCode;
            return response;
        }

        // Adds a new instance.
        [HttpPost]
        [Route("AddNutritionPlan")]
        public ResponseMessage AddNutritionPlan([FromBody] JObject data)
        {

            var response = NutritionPlanHelper.Add(data,
                context: Database.DbContext,
                statusCode: out HttpStatusCode statusCode,
                includeDetailedErrors: HostingEnvironment.IsDevelopment());
            HttpContext.Response.StatusCode = (int)statusCode;
            return response;
        }

        // Adds a new instance.
        [HttpGet]
        [Route("GetNutritionPlan")]
        public ResponseMessage GetNutritionPlan([FromBody] JObject data)
        {

            var response = NutritionPlanHelper.Get(data,
                context: Database.DbContext,
                statusCode: out HttpStatusCode statusCode,
                includeDetailedErrors: HostingEnvironment.IsDevelopment());
            HttpContext.Response.StatusCode = (int)statusCode;
            return response;
        }

        // Deletes an instance.
        [HttpDelete]
        [Route("DeleteNutritionPlan")]
        public ResponseMessage DeleteNutritionPlan([FromBody] JObject data)
        {

            var response = NutritionPlanHelper.Delete(data,
                context: Database.DbContext,
                statusCode: out HttpStatusCode statusCode,
                includeDetailedErrors: HostingEnvironment.IsDevelopment());
            HttpContext.Response.StatusCode = (int)statusCode;
            return response;
        }

        // Edits an instance.
        [HttpPut]
        [Route("EditNutritionPlan")]
        public ResponseMessage EditNutritionPlan([FromBody] JObject data)
        {

            var response = NutritionPlanHelper.Edit(data,
                context: Database.DbContext,
                statusCode: out HttpStatusCode statusCode,
                includeDetailedErrors: HostingEnvironment.IsDevelopment());
            HttpContext.Response.StatusCode = (int)statusCode;
            return response;
        }

    }
}
