﻿using BusinessLibrary.Models;
using DatabaseLibrary.Core;
using DatabaseLibrary.Models;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Webservice.ControllerHelpers
{
    public class CardioLogHelper
    {

        #region Converters

        /// <summary>
        /// Converts database models to a business logic object.
        /// </summary>
        public static BusinessLibrary.Models.CardioLog Convert(CardioLog_db instance)
        {
            if (instance == null)
                return null;
            return new BusinessLibrary.Models.CardioLog(instance.ClientId, instance.LogName, instance.LogDate, instance.CardioType, instance.StartTime, instance.EndTime, instance.CaloriesBurned);
        }

        #endregion

        /// <summary>
        /// Adds a cardio log.
        /// </summary>
        /// <param name="includeDetailedErrors">States whether the internal server error message should be detailed or not.</param>
        public static ResponseMessage Add(JObject data,
            DbContext context, out HttpStatusCode statusCode, bool includeDetailedErrors = false)
        {
            // Extract paramters
            int id = (data.ContainsKey("id")) ? data.GetValue("id").Value<int>() : 0;
            string name = (data.ContainsKey("name")) ? data.GetValue("name").Value<string>() : null;
            DateTime date = (data.ContainsKey("date")) ? data.GetValue("date").Value<DateTime>() : DateTime.MinValue;
            string cardioType = (data.ContainsKey("cardioType")) ? data.GetValue("cardioType").Value<string>() : null;
            TimeSpan startTime = (data.ContainsKey("startTime")) ? data.GetValue("startTime").Value<TimeSpan>() : TimeSpan.Zero;
            TimeSpan endTime = (data.ContainsKey("endTime")) ? data.GetValue("endTime").Value<TimeSpan>() : TimeSpan.Zero;
            int calories = (data.ContainsKey("calories")) ? data.GetValue("calories").Value<int>() : 0;

            // Add instance to database
            var dbInstance = DatabaseLibrary.Helpers.CardioLogHelper_db.Add(id, name, date, cardioType, startTime, endTime, calories,
                context, out StatusResponse statusResponse);

            // Get rid of detailed internal server error message (when requested)
            if (statusResponse.StatusCode == HttpStatusCode.InternalServerError
                && !includeDetailedErrors)
                statusResponse.Message = "Something went wrong while adding a new cardio log.";

            // Return response
            var response = new ResponseMessage
                (
                    dbInstance != null,
                    statusResponse.Message,
                    Convert(dbInstance)
                );
            statusCode = statusResponse.StatusCode;
            return response;
        }

        /// <summary>
        /// Gets list of cardio logs for a specific client.
        /// </summary>
        /// <param name="includeDetailedErrors">States whether the internal server error message should be detailed or not.</param>
        public static ResponseMessage GetCollection(JObject data,
            DbContext context, out HttpStatusCode statusCode, bool includeDetailedErrors = false)
        {
            int id = (data.ContainsKey("id")) ? data.GetValue("id").Value<int>() : 0;
            // Get instances from database
            var dbInstances = DatabaseLibrary.Helpers.CardioLogHelper_db.GetCollection(id,
                context, out StatusResponse statusResponse);

            // Convert to business logic objects
            var instances = dbInstances?.Select(x => Convert(x)).ToList();

            // Get rid of detailed error message (when requested)
            if (statusResponse.StatusCode == HttpStatusCode.InternalServerError
                && !includeDetailedErrors)
                statusResponse.Message = "Something went wrong while retrieving the clients";

            // Return response
            var response = new ResponseMessage
                (
                    instances != null,
                    statusResponse.Message,
                    instances
                );
            statusCode = statusResponse.StatusCode;
            return response;
        }

        /// <summary>
        /// Get a specific cardio log
        /// </summary>
        /// <param name="includeDetailedErrors">States whether the internal server error message should be detailed or not.</param>
        public static ResponseMessage Get(JObject data,
            DbContext context, out HttpStatusCode statusCode, bool includeDetailedErrors = false)
        {
            int id = (data.ContainsKey("id")) ? data.GetValue("id").Value<int>() : 0;
            DateTime date = (data.ContainsKey("date")) ? data.GetValue("date").Value<DateTime>() : DateTime.MinValue;
            TimeSpan start = (data.ContainsKey("start")) ? data.GetValue("start").Value<TimeSpan>() : TimeSpan.Zero;
            // Get instances from database
            var dbInstances = DatabaseLibrary.Helpers.CardioLogHelper_db.Get(id, date, start,
                context, out StatusResponse statusResponse);

            var instances = dbInstances?.Select(x => Convert(x)).ToList();
            var instance = instances.Take(1);

            // Get rid of detailed error message (when requested)
            if (statusResponse.StatusCode == HttpStatusCode.InternalServerError
                && !includeDetailedErrors)
                statusResponse.Message = "Something went wrong while retrieving the client";

            // Return response
            var response = new ResponseMessage
                (
                    instances != null,
                    statusResponse.Message,
                    instance
                );
            statusCode = statusResponse.StatusCode;
            return response;
        }

        /// <summary>
        /// Deletes a cardio log
        /// </summary>
        /// <param name="includeDetailedErrors">States whether the internal server error message should be detailed or not.</param>
        public static ResponseMessage Delete(JObject data,
            DbContext context, out HttpStatusCode statusCode, bool includeDetailedErrors = false)
        {
            int id = (data.ContainsKey("id")) ? data.GetValue("id").Value<int>() : 0;
            DateTime date = (data.ContainsKey("date")) ? data.GetValue("date").Value<DateTime>() : DateTime.MinValue;
            TimeSpan start = (data.ContainsKey("start")) ? data.GetValue("start").Value<TimeSpan>() : TimeSpan.Zero;
            // Get instances from database
            var dbInstances = DatabaseLibrary.Helpers.CardioLogHelper_db.Delete(id, date, start,
                context, out StatusResponse statusResponse);

            // Convert to business logic objects
            var instances = dbInstances;

            // Get rid of detailed error message (when requested)
            if (statusResponse.StatusCode == HttpStatusCode.InternalServerError
                && !includeDetailedErrors)
                statusResponse.Message = "Something went wrong while deleting the client";

            // Return response
            var response = new ResponseMessage
                (
                    instances != false,
                    statusResponse.Message,
                    instances
                );
            statusCode = statusResponse.StatusCode;
            return response;
        }

        /// <summary>
        /// Edits a cardio log
        /// </summary>
        /// <param name="includeDetailedErrors">States whether the internal server error message should be detailed or not.</param>
        public static ResponseMessage Edit(JObject data,
            DbContext context, out HttpStatusCode statusCode, bool includeDetailedErrors = false)
        {
            int id = (data.ContainsKey("id")) ? data.GetValue("id").Value<int>() : 0;
            string name = (data.ContainsKey("name")) ? data.GetValue("name").Value<string>() : null;
            DateTime date = (data.ContainsKey("date")) ? data.GetValue("date").Value<DateTime>() : DateTime.MinValue;
            string cardioType = (data.ContainsKey("cardioType")) ? data.GetValue("cardioType").Value<string>() : null;
            TimeSpan startTime = (data.ContainsKey("startTime")) ? data.GetValue("startTime").Value<TimeSpan>() : TimeSpan.Zero;
            TimeSpan endTime = (data.ContainsKey("endTime")) ? data.GetValue("endTime").Value<TimeSpan>() : TimeSpan.Zero;
            int calories = (data.ContainsKey("calories")) ? data.GetValue("calories").Value<int>() : 0;
            // Get instances from database
            var dbInstances = DatabaseLibrary.Helpers.CardioLogHelper_db.Edit(id, name, date, cardioType, startTime, endTime, calories,
                context, out StatusResponse statusResponse);

            // Convert to business logic objects
            var instances = dbInstances;

            // Get rid of detailed error message (when requested)
            if (statusResponse.StatusCode == HttpStatusCode.InternalServerError
                && !includeDetailedErrors)
                statusResponse.Message = "Something went wrong while retrieving the cardio log";

            // Return response
            var response = new ResponseMessage
                (
                    instances != false,
                    statusResponse.Message,
                    instances
                );
            statusCode = statusResponse.StatusCode;
            return response;
        }

    }
}
