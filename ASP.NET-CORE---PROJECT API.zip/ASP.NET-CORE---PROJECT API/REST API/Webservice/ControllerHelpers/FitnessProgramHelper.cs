﻿using BusinessLibrary.Models;
using DatabaseLibrary.Core;
using DatabaseLibrary.Models;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Webservice.ControllerHelpers
{
    public class FitnessProgramHelper
    {

        #region Converters

        /// <summary>
        /// Converts database models to a business logic object.
        /// </summary>
        public static BusinessLibrary.Models.FitnessProgram Convert(FitnessProgram_db instance)
        {
            if (instance == null)
                return null;
            return new BusinessLibrary.Models.FitnessProgram(instance.Id, instance.Name, instance.Description, instance.Routine, instance.CreationDate, instance.Video, instance.Type, instance.Modality);
        }

        #endregion

        /// <summary>
        /// Adds a cardio log.
        /// </summary>
        /// <param name="includeDetailedErrors">States whether the internal server error message should be detailed or not.</param>
        public static ResponseMessage Add(JObject data,
            DbContext context, out HttpStatusCode statusCode, bool includeDetailedErrors = false)
        {
            // Extract paramters
            int id = (data.ContainsKey("id")) ? data.GetValue("id").Value<int>() : 0;
            string name = (data.ContainsKey("name")) ? data.GetValue("name").Value<string>() : null;
            string description = (data.ContainsKey("description")) ? data.GetValue("description").Value<string>() : null;
            string routine = (data.ContainsKey("routine")) ? data.GetValue("routine").Value<string>() : null;
            DateTime creationDate = (data.ContainsKey("creationDate")) ? data.GetValue("creationDate").Value<DateTime>() : DateTime.MinValue;
            string video = (data.ContainsKey("video")) ? data.GetValue("video").Value<string>() : null;
            string type = (data.ContainsKey("type")) ? data.GetValue("type").Value<string>() : null;
            string modality = (data.ContainsKey("modality")) ? data.GetValue("modality").Value<string>() : null;

            // Add instance to database
            var dbInstance = DatabaseLibrary.Helpers.FitnessProgramHelper_db.Add(id, name, description, routine, creationDate, video, type, modality,
                context, out StatusResponse statusResponse);

            // Get rid of detailed internal server error message (when requested)
            if (statusResponse.StatusCode == HttpStatusCode.InternalServerError
                && !includeDetailedErrors)
                statusResponse.Message = "Something went wrong while adding a new fitness program.";

            // Return response
            var response = new ResponseMessage
                (
                    dbInstance != null,
                    statusResponse.Message,
                    Convert(dbInstance)
                );
            statusCode = statusResponse.StatusCode;
            return response;
        }

        /// <summary>
        /// Gets list of cardio logs for a specific client.
        /// </summary>
        /// <param name="includeDetailedErrors">States whether the internal server error message should be detailed or not.</param>
        public static ResponseMessage GetCollection(JObject data,
            DbContext context, out HttpStatusCode statusCode, bool includeDetailedErrors = false)
        {
            int id = (data.ContainsKey("id")) ? data.GetValue("id").Value<int>() : 0;
            // Get instances from database
            var dbInstances = DatabaseLibrary.Helpers.FitnessProgramHelper_db.GetCollection(id,
                context, out StatusResponse statusResponse);

            // Convert to business logic objects
            var instances = dbInstances?.Select(x => Convert(x)).ToList();

            // Get rid of detailed error message (when requested)
            if (statusResponse.StatusCode == HttpStatusCode.InternalServerError
                && !includeDetailedErrors)
                statusResponse.Message = "Something went wrong while retrieving the exercise sets";

            // Return response
            var response = new ResponseMessage
                (
                    instances != null,
                    statusResponse.Message,
                    instances
                );
            statusCode = statusResponse.StatusCode;
            return response;
        }

        /// <summary>
        /// Get a specific cardio log
        /// </summary>
        /// <param name="includeDetailedErrors">States whether the internal server error message should be detailed or not.</param>
        public static ResponseMessage Get(JObject data,
            DbContext context, out HttpStatusCode statusCode, bool includeDetailedErrors = false)
        {
            int id = (data.ContainsKey("id")) ? data.GetValue("id").Value<int>() : 0;
            string name = (data.ContainsKey("name")) ? data.GetValue("name").Value<string>() : null;
            // Get instances from database
            var dbInstances = DatabaseLibrary.Helpers.FitnessProgramHelper_db.Get(id, name,
                context, out StatusResponse statusResponse);

            var instances = dbInstances?.Select(x => Convert(x)).ToList();
            var instance = instances.Take(1);

            // Get rid of detailed error message (when requested)
            if (statusResponse.StatusCode == HttpStatusCode.InternalServerError
                && !includeDetailedErrors)
                statusResponse.Message = "Something went wrong while retrieving the exercise set";

            // Return response
            var response = new ResponseMessage
                (
                    instances != null,
                    statusResponse.Message,
                    instance
                );
            statusCode = statusResponse.StatusCode;
            return response;
        }

        /// <summary>
        /// Deletes a cardio log
        /// </summary>
        /// <param name="includeDetailedErrors">States whether the internal server error message should be detailed or not.</param>
        public static ResponseMessage Delete(JObject data,
            DbContext context, out HttpStatusCode statusCode, bool includeDetailedErrors = false)
        {
            int id = (data.ContainsKey("id")) ? data.GetValue("id").Value<int>() : 0;
            string name = (data.ContainsKey("name")) ? data.GetValue("name").Value<string>() : null;
            // Get instances from database
            var dbInstances = DatabaseLibrary.Helpers.FitnessProgramHelper_db.Delete(id, name,
                context, out StatusResponse statusResponse);

            // Convert to business logic objects
            var instances = dbInstances;

            // Get rid of detailed error message (when requested)
            if (statusResponse.StatusCode == HttpStatusCode.InternalServerError
                && !includeDetailedErrors)
                statusResponse.Message = "Something went wrong while deleting the exercise set";

            // Return response
            var response = new ResponseMessage
                (
                    instances != false,
                    statusResponse.Message,
                    instances
                );
            statusCode = statusResponse.StatusCode;
            return response;
        }

        /// <summary>
        /// Edits a cardio log
        /// </summary>
        /// <param name="includeDetailedErrors">States whether the internal server error message should be detailed or not.</param>
        public static ResponseMessage Edit(JObject data,
            DbContext context, out HttpStatusCode statusCode, bool includeDetailedErrors = false)
        {
            int id = (data.ContainsKey("id")) ? data.GetValue("id").Value<int>() : 0;
            string name = (data.ContainsKey("name")) ? data.GetValue("name").Value<string>() : null;
            string description = (data.ContainsKey("description")) ? data.GetValue("description").Value<string>() : null;
            string routine = (data.ContainsKey("routine")) ? data.GetValue("routine").Value<string>() : null;
            DateTime creationDate = (data.ContainsKey("creationDate")) ? data.GetValue("creationDate").Value<DateTime>() : DateTime.MinValue;
            string video = (data.ContainsKey("video")) ? data.GetValue("video").Value<string>() : null;
            string type = (data.ContainsKey("type")) ? data.GetValue("type").Value<string>() : null;
            string modality = (data.ContainsKey("modality")) ? data.GetValue("modality").Value<string>() : null;
            // Get instances from database
            var dbInstances = DatabaseLibrary.Helpers.FitnessProgramHelper_db.Edit(id, name, description, routine, creationDate, video, type, modality,
                context, out StatusResponse statusResponse);

            // Convert to business logic objects
            var instances = dbInstances;

            // Get rid of detailed error message (when requested)
            if (statusResponse.StatusCode == HttpStatusCode.InternalServerError
                && !includeDetailedErrors)
                statusResponse.Message = "Something went wrong while retrieving the cardio log";

            // Return response
            var response = new ResponseMessage
                (
                    instances != false,
                    statusResponse.Message,
                    instances
                );
            statusCode = statusResponse.StatusCode;
            return response;
        }

    }
}
