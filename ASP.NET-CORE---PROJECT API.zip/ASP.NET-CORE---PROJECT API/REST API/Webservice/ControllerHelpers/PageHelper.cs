﻿using BusinessLibrary.Models;
using DatabaseLibrary.Core;
using DatabaseLibrary.Models;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Webservice.ControllerHelpers
{
    public class PageHelper
    {

        #region Converters

        /// <summary>
        /// Converts database models to a business logic object.
        /// </summary>
        public static BusinessLibrary.Models.Page Convert(Page_db instance)
        {
            if (instance == null)
                return null;
            return new BusinessLibrary.Models.Page(instance.Id, instance.Topic, instance.Content, instance.Author, instance.WriteDate, instance.ViewCount);
        }

        #endregion

        /// <summary>
        /// Signs up a Page.
        /// </summary>
        /// <param name="includeDetailedErrors">States whether the internal server error message should be detailed or not.</param>
        public static ResponseMessage Add(JObject data,
            DbContext context, out HttpStatusCode statusCode, bool includeDetailedErrors = false)
        {
            // Extract paramters
            string topic = (data.ContainsKey("topic")) ? data.GetValue("topic").Value<string>() : null;
            string content = (data.ContainsKey("content")) ? data.GetValue("content").Value<string>() : null;
            string author = (data.ContainsKey("author")) ? data.GetValue("author").Value<string>() : null;
            DateTime writeDate = (data.ContainsKey("writeDate")) ? data.GetValue("writeDate").Value<DateTime>() : DateTime.MinValue;
            int viewCount = (data.ContainsKey("viewCount")) ? data.GetValue("viewCount").Value<int>() : 0;

            // Add instance to database
            var dbInstance = DatabaseLibrary.Helpers.PageHelper_db.Add(topic, content, author, writeDate, viewCount,
                context, out StatusResponse statusResponse);

            // Get rid of detailed internal server error message (when requested)
            if (statusResponse.StatusCode == HttpStatusCode.InternalServerError
                && !includeDetailedErrors)
                statusResponse.Message = "Something went wrong while adding a new Page.";

            // Return response
            var response = new ResponseMessage
                (
                    dbInstance != null,
                    statusResponse.Message,
                    Convert(dbInstance)
                );
            statusCode = statusResponse.StatusCode;
            return response;
        }

        /// <summary>
        /// Gets list of Pages.
        /// </summary>
        /// <param name="includeDetailedErrors">States whether the internal server error message should be detailed or not.</param>
        public static ResponseMessage GetCollection(
            DbContext context, out HttpStatusCode statusCode, bool includeDetailedErrors = false)
        {
            // Get instances from database
            var dbInstances = DatabaseLibrary.Helpers.PageHelper_db.GetCollection(
                context, out StatusResponse statusResponse);

            // Convert to business logic objects
            var instances = dbInstances?.Select(x => Convert(x)).ToList();

            // Get rid of detailed error message (when requested)
            if (statusResponse.StatusCode == HttpStatusCode.InternalServerError
                && !includeDetailedErrors)
                statusResponse.Message = "Something went wrong while retrieving the Pages";

            // Return response
            var response = new ResponseMessage
                (
                    instances != null,
                    statusResponse.Message,
                    instances
                );
            statusCode = statusResponse.StatusCode;
            return response;
        }

        /// <summary>
        /// Gets list of Pages.
        /// </summary>
        /// <param name="includeDetailedErrors">States whether the internal server error message should be detailed or not.</param>
        public static ResponseMessage Get(JObject data,
            DbContext context, out HttpStatusCode statusCode, bool includeDetailedErrors = false)
        {
            int id = (data.ContainsKey("id")) ? data.GetValue("id").Value<int>() : 0;
            // Get instances from database
            var dbInstances = DatabaseLibrary.Helpers.PageHelper_db.Get(id,
                context, out StatusResponse statusResponse);

            var instances = dbInstances?.Select(x => Convert(x)).ToList();
            var instance = instances.Take(1);

            // Get rid of detailed error message (when requested)
            if (statusResponse.StatusCode == HttpStatusCode.InternalServerError
                && !includeDetailedErrors)
                statusResponse.Message = "Something went wrong while retrieving the Page";

            // Return response
            var response = new ResponseMessage
                (
                    instances != null,
                    statusResponse.Message,
                    instance
                );
            statusCode = statusResponse.StatusCode;
            return response;
        }

        /// <summary>
        /// Gets list of Pages.
        /// </summary>
        /// <param name="includeDetailedErrors">States whether the internal server error message should be detailed or not.</param>
        public static ResponseMessage Delete(JObject data,
            DbContext context, out HttpStatusCode statusCode, bool includeDetailedErrors = false)
        {
            int id = (data.ContainsKey("id")) ? data.GetValue("id").Value<int>() : 0;
            // Get instances from database
            var dbInstances = DatabaseLibrary.Helpers.PageHelper_db.Delete(id,
                context, out StatusResponse statusResponse);

            // Convert to business logic objects
            var instances = dbInstances;

            // Get rid of detailed error message (when requested)
            if (statusResponse.StatusCode == HttpStatusCode.InternalServerError
                && !includeDetailedErrors)
                statusResponse.Message = "Something went wrong while deleting the Page";

            // Return response
            var response = new ResponseMessage
                (
                    instances != false,
                    statusResponse.Message,
                    instances
                );
            statusCode = statusResponse.StatusCode;
            return response;
        }

        /// <summary>
        /// Gets list of Pages.
        /// </summary>
        /// <param name="includeDetailedErrors">States whether the internal server error message should be detailed or not.</param>
        public static ResponseMessage Edit(JObject data,
            DbContext context, out HttpStatusCode statusCode, bool includeDetailedErrors = false)
        {
            int id = (data.ContainsKey("id")) ? data.GetValue("id").Value<int>() : 0;
            string topic = (data.ContainsKey("topic")) ? data.GetValue("topic").Value<string>() : null;
            string content = (data.ContainsKey("content")) ? data.GetValue("content").Value<string>() : null;
            string author = (data.ContainsKey("author")) ? data.GetValue("author").Value<string>() : null;
            DateTime writeDate = (data.ContainsKey("writeDate")) ? data.GetValue("writeDate").Value<DateTime>() : DateTime.MinValue;
            int viewCount = (data.ContainsKey("viewCount")) ? data.GetValue("viewCount").Value<int>() : 0;
            // Get instances from database
            var dbInstances = DatabaseLibrary.Helpers.PageHelper_db.Edit(id, topic, content, author, writeDate, viewCount,
                context, out StatusResponse statusResponse);

            // Convert to business logic objects
            var instances = dbInstances;

            // Get rid of detailed error message (when requested)
            if (statusResponse.StatusCode == HttpStatusCode.InternalServerError
                && !includeDetailedErrors)
                statusResponse.Message = "Something went wrong while retrieving the Pages";

            // Return response
            var response = new ResponseMessage
                (
                    instances != false,
                    statusResponse.Message,
                    instances
                );
            statusCode = statusResponse.StatusCode;
            return response;
        }

    }
}
