﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DatabaseLibrary.Models
{
	public class Page_db
	{
		#region Constructors
		public Page_db()
		{
		}

		public Page_db(int id, string topic, string content, string author, DateTime writeDate, int viewCount)
		{
			Id = id;
			Topic = topic;
			Content = content;
			Author = author;
			WriteDate = writeDate;
			ViewCount = viewCount;
		}

		#endregion

		#region Properties
		public int Id { get; set; }

		public string Topic { get; set; }

		public string Content { get; set; }

		public string Author { get; set; }

		public DateTime WriteDate { get; set; }

		public int ViewCount { get; set; }

		#endregion

		#region Methods

		#endregion
	}
}
