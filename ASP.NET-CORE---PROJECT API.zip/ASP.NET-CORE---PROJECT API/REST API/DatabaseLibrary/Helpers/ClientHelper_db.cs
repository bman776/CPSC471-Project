﻿using DatabaseLibrary.Core;
using DatabaseLibrary.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Net;
using System.Text;

namespace DatabaseLibrary.Helpers
{
    public class ClientHelper_db
    {

        /// <summary>
        /// Adds a new instance into the database.
        /// </summary>
        public static Client_db Add(string name, DateTime dob, Decimal weight, Decimal height, Decimal waistCirc, Decimal hipCirc, Decimal neckCirc,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Validate
                if (string.IsNullOrEmpty(name?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a name.");
                if (dob == DateTime.MinValue)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid date.");
                if (weight < 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid weight.");
                if (height < 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid height.");
                if (waistCirc < 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid waist circumference.");
                if (hipCirc < 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid hip circumference.");
                if (neckCirc < 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid neck circumference.");

                // Generate a new instance
                Client_db instance = new Client_db
                    (
                        id: Convert.ToInt32(Guid.NewGuid()), //This can be ignored is PK in your DB is auto increment
                        name, dob, weight, height, waistCirc, hipCirc, neckCirc
                    );

                // Add to database
                int rowsAffected = context.ExecuteNonQueryCommand
                    (
                        commandText:
                        "BEGIN; " +
                        "INSERT INTO client (clientID, weight, height, waist_circ, hip_circ, neck_circ) values (@id, @weight, @height, @waist, @hip, @neck); " +
                        "INSERT INTO user (userID, name, DoB) values (@id, @name, @dob); " +
                        "COMMIT;",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", instance.Id },
                            { "@name", instance.Name },
                            { "@dob", instance.DoB },
                            { "@weight", instance.Weight },
                            { "@height", instance.Height },
                            { "@waist_circ", instance.WaistCirc },
                            { "@hip_circ", instance.HipCirc },
                            { "@neck_circ", instance.NeckCirc }

                        },
                        message: out string message
                    );
                if (rowsAffected == -1)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("Client added successfully");
                return instance;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        /// <summary>
        /// Retrieves a list of instances.
        /// </summary>
        public static List<Client_db> GetCollection(
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Get from database
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText: "SELECT * FROM (client AS client(userId, weight, height, waist_circ, hip_circ, neck_circ)) NATURAL JOIN  user",
                        parameters: new Dictionary<string, object>()
                        {

                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                // Parse data
                List<Client_db> instances = new List<Client_db>();
                foreach (DataRow row in table.Rows)
                    instances.Add(new Client_db
                            (
                                id: Convert.ToInt32(row["userId"]),
                                name: row["name"].ToString(), 
                                dob: Convert.ToDateTime(row["dob"]),
                                weight: Convert.ToDecimal(row["weight"]),
                                height: Convert.ToDecimal(row["height"]),
                                waistCirc: Convert.ToDecimal(row["waist_circ"]),
                                hipCirc: Convert.ToDecimal(row["hip_circ"]),
                                neckCirc: Convert.ToDecimal(row["neck_circ"])
                            )
                        );

                // Return value
                statusResponse = new StatusResponse("Clients list has been retrieved successfully.");
                return instances;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        /// <summary>
        /// Retrieves a single instance.
        /// </summary>
        public static List<Client_db> Get(int id,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Get from database
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText: "SELECT * FROM (client AS client(userId, weight, height, waist_circ, hip_circ, neck_circ)) NATURAL JOIN  user WHERE userId = @id",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id }
                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                // Parse data
                List<Client_db> instances = new List<Client_db>();
                foreach (DataRow row in table.Rows)
                    instances.Add(new Client_db
                            (
                                id: Convert.ToInt32(row["userId"]),
                                name: row["name"].ToString(),
                                dob: Convert.ToDateTime(row["dob"]),
                                weight: Convert.ToDecimal(row["weight"]),
                                height: Convert.ToDecimal(row["height"]),
                                waistCirc: Convert.ToDecimal(row["waist_circ"]),
                                hipCirc: Convert.ToDecimal(row["hip_circ"]),
                                neckCirc: Convert.ToDecimal(row["neck_circ"])
                            )
                        );

                // Return value
                statusResponse = new StatusResponse("Client has been retrieved successfully.");
                return instances;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        /// <summary>
        /// Deletes an instance.
        /// </summary>
        public static bool Delete(int id,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Get from database
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText:
                        "BEGIN; " +
                        "DELETE FROM client WHERE clientId = @id; " +
                        "DELETE FROM user WHERE userId = @id; " + 
                        "COMMIT;",

                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id }
                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("Client has been deleted successfully.");
                return true;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return false;
            }
        }

        /// <summary>
        /// Adds a new instance into the database.
        /// </summary>
        public static bool Edit(int id, string name, DateTime dob, Decimal weight, Decimal height, Decimal waistCirc, Decimal hipCirc, decimal neckCirc,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Validate
                if (id == 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid id.");
                if (string.IsNullOrEmpty(name?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a name.");
                if (dob == DateTime.MinValue)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid date.");
                if (weight < 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid weight.");
                if (height < 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid height.");
                if (waistCirc < 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid waist circumference.");
                if (hipCirc < 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid hip circumference.");
                if (neckCirc < 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid neck circumference.");

                // Add to database
                int rowsAffected = context.ExecuteNonQueryCommand
                    (
                        commandText:
                        "BEGIN; " +
                        "UPDATE client weight= @weight, height= @height, waist_circ = @waist, hip_circ = @hip, neck_circ = @neck WHERE clientId = @id; " +
                        "UPDATE user name = @name, DoB = @dob WHERE userId = @id; " +
                        "COMMIT;",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id },
                            { "@name", name },
                            { "@dob", dob },
                            { "@weight", weight },
                            { "@height", height },
                            { "@waist_circ", waistCirc },
                            { "@hip_circ", hipCirc },
                            { "@neck_circ", neckCirc }

                        },
                        message: out string message
                    );
                if (rowsAffected == -1)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("Client edited successfully");
                return true;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return false;
            }
        }

    }
}
