﻿using DatabaseLibrary.Core;
using DatabaseLibrary.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Net;
using System.Text;

namespace DatabaseLibrary.Helpers
{
    public class PageHelper_db
    {

        public static Page_db Add(string topic, string content, string author, DateTime writeDate, int viewCount,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                if (string.IsNullOrEmpty(topic?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a topic.");
                if (string.IsNullOrEmpty(content?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide the content.");
                if (string.IsNullOrEmpty(author?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide an author.");
                if (writeDate == DateTime.MinValue)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid date.");

                Page_db instance = new Page_db
                    (
                        id: Convert.ToInt32(Guid.NewGuid()),
                        topic, content, author, writeDate, viewCount
                    );

                // Add to database
                int rowsAffected = context.ExecuteNonQueryCommand
                    (
                        commandText: "INSERT INTO nutrition_plan (pageID, content, topic, view_count, author, write_date) values (@id, @content, @topic, @view_count, @author, @date)",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", instance.Id },
                            { "@topic", instance.Topic },
                            { "@content", instance.Content },
                            { "@author", instance.Author },
                            { "@date", instance.WriteDate },
                            { "@views", instance.ViewCount }
                        },
                        message: out string message
                    );
                if (rowsAffected == -1)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("Page has been retrieved successfully.");
                return instance;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        public static List<Page_db> GetCollection(
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText: "SELECT * FROM page",
                        parameters: new Dictionary<string, object>()
                        {
                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                List<Page_db> instances = new List<Page_db>();
                foreach (DataRow row in table.Rows)
                    instances.Add(new Page_db
                            (
                                id: Convert.ToInt32(row["pageID"]),
                                content: row["content"].ToString(),
                                topic: row["topic"].ToString(),
                                viewCount: Convert.ToInt32(row["view_count"]),
                                author: row["author"].ToString(),
                                writeDate: Convert.ToDateTime(row["write_date"])
                            )
                        );

                // Return value
                statusResponse = new StatusResponse("Nutrition Plans list has been retrieved successfully.");
                return instances;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        public static List<Page_db> Get(int id,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText: "SELECT * FROM page WHERE pageID = @id",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id }
                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                List<Page_db> instances = new List<Page_db>();
                foreach (DataRow row in table.Rows)
                    instances.Add(new Page_db
                            (
                                id: Convert.ToInt32(row["pageID"]),
                                content: row["content"].ToString(),
                                topic: row["topic"].ToString(),
                                viewCount: Convert.ToInt32(row["view_count"]),
                                author: row["author"].ToString(),
                                writeDate: Convert.ToDateTime(row["write_date"])
                            )
                        );

                // Return value
                statusResponse = new StatusResponse("Nutrition Plan has been retrieved successfully.");
                return instances;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        /// <summary>
        /// Deletes an instance.
        /// </summary>
        public static bool Delete(int id,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Get from database
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText: "DELETE FROM page WHERE pageID = @id",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id }
                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("Nutrition Plan has been deleted successfully.");
                return true;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return false;
            }
        }

        public static bool Edit(int id, string topic, string content, string author, DateTime writeDate, int viewCount,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Validate
                if (id == 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide an id.");
                if (string.IsNullOrEmpty(topic?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a topic.");
                if (string.IsNullOrEmpty(content?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide the content.");
                if (string.IsNullOrEmpty(author?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide an author.");
                if (writeDate == DateTime.MinValue)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid date.");

                // Add to database
                int rowsAffected = context.ExecuteNonQueryCommand
                    (
                        commandText: "UPDATE page content = @content, topic = @topic, view_count = @views, author = @author, write_date = @date",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id },
                            { "@topic", topic },
                            { "@content", content },
                            { "@author", author },
                            { "@date", writeDate },
                            { "@views", viewCount }
                        },
                        message: out string message
                    );
                if (rowsAffected == -1)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("Nutrition Plan edited successfully");
                return true;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return false;
            }
        }
    }
}
