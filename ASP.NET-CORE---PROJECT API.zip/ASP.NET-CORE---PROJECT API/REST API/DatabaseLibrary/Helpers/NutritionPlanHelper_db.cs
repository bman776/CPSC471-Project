﻿using DatabaseLibrary.Core;
using DatabaseLibrary.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Net;
using System.Text;

namespace DatabaseLibrary.Helpers
{
    public class NutritionPlanHelper_db
    {

        public static NutritionPlan_db Add(int id, string name, string description, DateTime creationDate, string groceryList, string mealPlan,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                if (id == 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide an id.");
                if (string.IsNullOrEmpty(name?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a name.");
                if (string.IsNullOrEmpty(description?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a description.");
                if (string.IsNullOrEmpty(groceryList?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a grocery list.");
                if (string.IsNullOrEmpty(mealPlan?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a meal plan.");
                if (creationDate == DateTime.MinValue)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid date.");

                NutritionPlan_db instance = new NutritionPlan_db
                    (
                        id, name, description, creationDate, groceryList, mealPlan
                    );

                // Add to database
                int rowsAffected = context.ExecuteNonQueryCommand
                    (
                        commandText: "INSERT INTO nutrition_plan (dietician_authorID, name, description, creation_date, grocery_list, meal_plan) values (@id, @name, @description, @date, @grocery_list, @vmeal_plan)",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", instance.Id },
                            { "@name", instance.Name },
                            { "@description", instance.Description },
                            { "@date", instance.CreationDate },
                            { "@grocery_list", instance.GroceryList },
                            { "@meal_plan", instance.MealPlan }
                        },
                        message: out string message
                    );
                if (rowsAffected == -1)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("Nutrition Plan has been retrieved successfully.");
                return instance;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        public static List<NutritionPlan_db> GetCollection(int id,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText: "SELECT * FROM nutrition_plan WHERE dietician_authorID = @id",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id }
                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                List<NutritionPlan_db> instances = new List<NutritionPlan_db>();
                foreach (DataRow row in table.Rows)
                    instances.Add(new NutritionPlan_db
                            (
                                id: Convert.ToInt32(row["instructor_authorID"]),
                                name: row["name"].ToString(),
                                description: row["description"].ToString(),
                                creationDate: Convert.ToDateTime(row["creation_date"]),
                                groceryList: row["grocery_list"].ToString(),
                                mealPlan: row["meal_plan"].ToString()
                            )
                        );

                // Return value
                statusResponse = new StatusResponse("Nutrition Plans list has been retrieved successfully.");
                return instances;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        public static List<NutritionPlan_db> Get(int id, string name,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText: "SELECT * FROM nutrition_plan WHERE dietician_authorID = @id, name = @name",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id },
                            { "@name", name }
                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                List<NutritionPlan_db> instances = new List<NutritionPlan_db>();
                foreach (DataRow row in table.Rows)
                    instances.Add(new NutritionPlan_db
                            (
                                id: Convert.ToInt32(row["instructor_authorID"]),
                                name: row["name"].ToString(),
                                description: row["description"].ToString(),
                                creationDate: Convert.ToDateTime(row["creation_date"]),
                                groceryList: row["grocery_list"].ToString(),
                                mealPlan: row["meal_plan"].ToString()
                            )
                        );

                // Return value
                statusResponse = new StatusResponse("Nutrition Plan has been retrieved successfully.");
                return instances;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        /// <summary>
        /// Deletes an instance.
        /// </summary>
        public static bool Delete(int id, string name,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Get from database
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText: "DELETE FROM nutrition_plan WHERE dietician_authorID = @id, name = @name",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id },
                            { "@name", name }
                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("Nutrition Plan has been deleted successfully.");
                return true;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return false;
            }
        }

        public static bool Edit(int id, string name, string description, DateTime creationDate, string groceryList, string mealPlan,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Validate
                if (id == 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide an id.");
                if (string.IsNullOrEmpty(name?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a name.");
                if (string.IsNullOrEmpty(description?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a description.");
                if (string.IsNullOrEmpty(groceryList?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a grocery list.");
                if (string.IsNullOrEmpty(mealPlan?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a meal plan.");
                if (creationDate == DateTime.MinValue)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid date.");
                throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid date.");

                // Add to database
                int rowsAffected = context.ExecuteNonQueryCommand
                    (
                        commandText: "UPDATE nutrition_plan dietician_authorID = @id, name = @name, description = @description, creation_date = @date, grocery_list = @grocery_list, meal_plan = @meal_plan",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id },
                            { "@name", name },
                            { "@description", description },
                            { "@date", creationDate },
                            { "@grocery_list", groceryList },
                            { "@meal_plan", mealPlan }
                        },
                        message: out string message
                    );
                if (rowsAffected == -1)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("Nutrition Plan edited successfully");
                return true;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return false;
            }
        }
    }
}
