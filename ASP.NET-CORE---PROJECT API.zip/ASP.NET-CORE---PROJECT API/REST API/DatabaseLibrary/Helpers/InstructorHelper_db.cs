﻿using DatabaseLibrary.Core;
using DatabaseLibrary.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Net;
using System.Text;

namespace DatabaseLibrary.Helpers
{
    public class InstructorHelper_db
    {
        /// <summary>
        /// Adds a new instance into the database.
        /// </summary>
        public static Instructor_db Add(string name, DateTime dob, string trainingPhilosophy, int clientPopulation, string accreditation,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                //Validate
                if (string.IsNullOrEmpty(name?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a log name.");
                if (dob == DateTime.MinValue)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid date.");
                if (string.IsNullOrEmpty(trainingPhilosophy?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a training philosophy.");
                if (clientPopulation < 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid client population.");
                if (string.IsNullOrEmpty(accreditation?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide an accredtitation.");

                Instructor_db instance = new Instructor_db
                    (
                        id: Convert.ToInt32(Guid.NewGuid()), //This can be ignored is PK in your DB is auto increment
                        dob, name, trainingPhilosophy, clientPopulation, accreditation
                    );

                // Add to database
                int rowsAffected = context.ExecuteNonQueryCommand
                    (
                        commandText:
                        "BEGIN; " +
                        "INSERT INTO instructor (instructorID, client_pop, training_philosophy, accreditation) values (@id, @client_pop, @training_phil, @accreditation); " +
                        "INSERT INTO user (userID, name, DoB) values (@id, @name, @dob); " +
                        "COMMIT;",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", instance.Id },
                            { "@name", instance.Name },
                            { "@date", instance.Dob },
                            { "@client_pop", instance.ClientPopulation },
                            { "@training_phil", instance.TrainingPhilosophy },
                            { "@accreditation", instance.Accreditation }

                        },
                        message: out string message
                    );
                if (rowsAffected == -1)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("Cardio Log added successfully");
                return instance;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        /// <summary>
        /// Retrieves a list of instances.
        /// </summary>
        public static List<Instructor_db> GetCollection(
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Get from database
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText: "SELECT * FROM (instructr AS insructor(userID, client_pop, training_philosophy, accreditation)) NATURAL JOIN user",
                        parameters: new Dictionary<string, object>()
                        {
                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                // Parse data
                List<Instructor_db> instances = new List<Instructor_db>();
                foreach (DataRow row in table.Rows)
                    instances.Add(new Instructor_db
                            (
                                id: Convert.ToInt32(row["userID"]),
                                name: row["name"].ToString(),
                                dob: Convert.ToDateTime(row["DoB"]),
                                trainingPhilosophy: row["training_philosophy"].ToString(),
                                clientPopulation: Convert.ToInt32(row["client_pop"]),
                                accreditation: row["accreditation"].ToString()
                            )
                        );

                // Return value
                statusResponse = new StatusResponse("Instructors list has been retrieved successfully.");
                return instances;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        /// <summary>
        /// Retrieves a single instance.
        /// </summary>
        public static List<Instructor_db> Get(int id,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Get from database
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText: "SELECT * FROM (instructr AS insructor(userID, client_pop, training_philosophy, accreditation)) NATURAL JOIN user WHERE userID = @id",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id }
                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                // Parse data
                List<Instructor_db> instances = new List<Instructor_db>();
                foreach (DataRow row in table.Rows)
                    instances.Add(new Instructor_db
                            (
                                id: Convert.ToInt32(row["userID"]),
                                name: row["name"].ToString(),
                                dob: Convert.ToDateTime(row["DoB"]),
                                trainingPhilosophy: row["training_philosophy"].ToString(),
                                clientPopulation: Convert.ToInt32(row["client_pop"]),
                                accreditation: row["accreditation"].ToString()
                            )
                        );

                // Return value
                statusResponse = new StatusResponse("Instructor has been retrieved successfully.");
                return instances;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        /// <summary>
        /// Deletes an instance.
        /// </summary>
        public static bool Delete(int id,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Get from database
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText:
                        "BEGIN; " +
                        "DELETE FROM instructor WHERE instructorID = @id;" +
                        "DELETE FROM user WHERE userId = @id; " +
                        "COMMIT;",

                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id },
                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("Instructor has been deleted successfully.");
                return true;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return false;
            }
        }

        /// <summary>
        /// Adds a new instance into the database.
        /// </summary>
        public static bool Edit(int id, string name, DateTime dob, string trainingPhilosophy, int clientPopulation, string accreditation,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Validate
                if (id == 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid id.");
                if (string.IsNullOrEmpty(name?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a log name.");
                if (dob == DateTime.MinValue)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid date.");
                if (string.IsNullOrEmpty(trainingPhilosophy?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a training philosophy.");
                if (clientPopulation < 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid client population.");
                if (string.IsNullOrEmpty(accreditation?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide an accredtitation.");

                // Add to database
                int rowsAffected = context.ExecuteNonQueryCommand
                    (
                        commandText:
                        "BEGIN; " +
                        "UPDATE instructor client_pop = @client_pop, training_philosophy = @training_phil, accreditation = @accreditation WHERE instructorID = @id" +
                        "UPDATE user name = @name, DoB = @dob WHERE userId = @id; " +
                        "COMMIT;",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id },
                            { "@name", name },
                            { "@date", dob },
                            { "@client_pop", clientPopulation },
                            { "@training_phil", trainingPhilosophy },
                            { "@accreditation", accreditation }
                        },
                        message: out string message
                    );
                if (rowsAffected == -1)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("Instructor edited successfully");
                return true;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return false;
            }
        }
    }
}
