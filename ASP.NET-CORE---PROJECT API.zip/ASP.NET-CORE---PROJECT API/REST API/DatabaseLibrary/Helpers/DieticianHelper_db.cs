﻿using DatabaseLibrary.Core;
using DatabaseLibrary.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Net;
using System.Text;

namespace DatabaseLibrary.Helpers
{
    public class DieticianHelper_db
    {
        public static Dietician_db Add(string name, DateTime dob, string practice, string doctorate, string bachelors, string associates, string certification,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                if (string.IsNullOrEmpty(name?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a name.");
                if (dob == DateTime.MinValue)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid date.");
                if (string.IsNullOrEmpty(practice?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a practice.");
                if (string.IsNullOrEmpty(doctorate?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a doctorate.");
                if (string.IsNullOrEmpty(bachelors?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a bachelor's degree.");
                if (string.IsNullOrEmpty(associates?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide an associate's degree.");
                if (string.IsNullOrEmpty(certification?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide certification.");

                Dietician_db instance = new Dietician_db
                (
                    id: Convert.ToInt32(Guid.NewGuid()), //This can be ignored is PK in your DB is auto increment
                    dob, name, practice, doctorate, bachelors, associates, certification

                );

                int rowsAffected = context.ExecuteNonQueryCommand
                    (
                        commandText:
                        "BEGIN; " +
                        "INSERT INTO dietician (dieticianId, practice, doctorate, bachelors_degree, associates_degree, certification/diploma) values (@id, @practice, @doctorate, @bachelors, @associates, @certificataion); " +
                        "INSERT INTO user (userId, name, DoB) values (@id, @name, @dob); " +
                        "COMMIT;",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", instance.Id },
                            { "@name", instance.Name },
                            { "@dob", instance.Dob },
                            { "@practice", instance.Practice },
                            { "@doctorate", instance.Doctorate },
                            { "@bachelors", instance.BachelorsDegree },
                            { "@associates", instance.AssociateDegree },
                            { "@certification", instance.Certification }

                        },
                        message: out string message
                    );
                if (rowsAffected == -1)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("Dietician added successfully");
                return instance;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        public static List<Dietician_db> GetCollection(
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Get from database
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText: "SELECT * FROM (dietician AS dietician(userID, practice, doctorate, bachelors_degree, associate_degree, certification/diploma)) NATURAL JOIN  user",
                        parameters: new Dictionary<string, object>()
                        {
                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                // Parse data
                List<Dietician_db> instances = new List<Dietician_db>();
                foreach (DataRow row in table.Rows)
                    instances.Add(new Dietician_db
                            (
                                id: Convert.ToInt32(row["userID"]),
                                name: row["name"].ToString(),
                                dob: Convert.ToDateTime(row["dob"]),
                                practice: row["practice"].ToString(),
                                doctorate: row["doctorate"].ToString(),
                                bachelorsDegree: row["bachelors_degree"].ToString(),
                                associateDegree: row["associate_degree"].ToString(),
                                certification: row["certification/diplom"].ToString()
                            )
                        );

                // Return value
                statusResponse = new StatusResponse("Dietician list has been retrieved successfully.");
                return instances;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        public static List<Dietician_db> Get(int id,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Get from database
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText: "SELECT * FROM (dietician AS dietician(userID, practice, doctorate, bachelors_degree, associate_degree, certification/diploma)) NATURAL JOIN  user WHERE userID = @id",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id }
                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                // Parse data
                List<Dietician_db> instances = new List<Dietician_db>();
                foreach (DataRow row in table.Rows)
                    instances.Add(new Dietician_db
                            (
                                id: Convert.ToInt32(row["userID"]),
                                name: row["name"].ToString(),
                                dob: Convert.ToDateTime(row["dob"]),
                                practice: row["practice"].ToString(),
                                doctorate: row["doctorate"].ToString(),
                                bachelorsDegree: row["bachelors_degree"].ToString(),
                                associateDegree: row["associate_degree"].ToString(),
                                certification: row["certification/diplom"].ToString()
                            )
                        );

                // Return value
                statusResponse = new StatusResponse("Dietician list has been retrieved successfully.");
                return instances;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        /// <summary>
        /// Deletes an instance.
        /// </summary>
        public static bool Delete(int id,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Get from database
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText:
                        "BEGIN; " +
                        "DELETE FROM dietician WHERE dieticianID = @id" +
                        "DELETE FROM user WHERE userID = @id" +
                        "COMMIT;",

                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id },
                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("Dietician has been deleted successfully.");
                return true;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return false;
            }
        }

        /// <summary>
        /// Adds a new instance into the database.
        /// </summary>
        public static bool Edit(int id, string name, DateTime dob, string practice, string doctorate, string bachelors, string associates, string certification,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Validate
                if (id == 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid id.");
                if (string.IsNullOrEmpty(name?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a name.");
                if (dob == DateTime.MinValue)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid date.");
                if (string.IsNullOrEmpty(practice?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a practice.");
                if (string.IsNullOrEmpty(doctorate?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a doctorate.");
                if (string.IsNullOrEmpty(bachelors?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a bachelor's degree.");
                if (string.IsNullOrEmpty(associates?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide an associate's degree.");
                if (string.IsNullOrEmpty(certification?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide certification.");

                // Add to database
                int rowsAffected = context.ExecuteNonQueryCommand
                    (
                        commandText:
                        "BEGIN; " +
                        "UPDATE dietician practice = @practice, doctorate = @doctorate, bachelors_degree = @bachelors, associate_degree = @associates, certification/diplom = @certification WHERE dieticianID = @id;" +
                        "UPDATE user name = @name, DoB = @dob WHERE userID = @id;" +
                        "COMMIT; ",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id },
                            { "@name", name },
                            { "@dob", dob },
                            { "@practice", practice },
                            { "@doctorate", doctorate },
                            { "@bachelors", bachelors },
                            { "@associates", associates },
                            { "@certification", certification }
                        },
                        message: out string message
                    );
                if (rowsAffected == -1)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("Dietician edited successfully");
                return true;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return false;
            }
        }
    }
}
