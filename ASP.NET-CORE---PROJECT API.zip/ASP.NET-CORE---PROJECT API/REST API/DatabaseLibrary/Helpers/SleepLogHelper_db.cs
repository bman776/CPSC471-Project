﻿using DatabaseLibrary.Core;
using DatabaseLibrary.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Net;
using System.Text;

namespace DatabaseLibrary.Helpers
{
    public class SleepLogHelper_db
    {

        public static SleepLog_db Add(int id, DateTime date, TimeSpan time, int duration,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                //Validate
                if (id == 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid id.");
                if (date == DateTime.MinValue)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid date.");
                if (time == TimeSpan.Zero)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a type.");
                if (duration == 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide the number of calories burned.");

                SleepLog_db instance = new SleepLog_db
                    (
                        id, date, time, duration
                    );

                // Add to database
                int rowsAffected = context.ExecuteNonQueryCommand
                    (
                        commandText:
                        "INSERT INTO cardio_log (clientID, date, time, duration) values (@id, @date, @time, @duration)",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", instance.Id },
                            { "@date", instance.Date },
                            { "@time", instance.Time },
                            { "@duration", instance.SleepDuration },
                        },
                        message: out string message
                    );
                if (rowsAffected == -1)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("Cardio Log added successfully");
                return instance;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        /// <summary>
        /// Retrieves a list of instances.
        /// </summary>
        public static List<SleepLog_db> GetCollection(int id,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Get from database
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText: "SELECT * FROM cardio_log WHERE clientID = @id",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id }
                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                // Parse data
                List<SleepLog_db> instances = new List<SleepLog_db>();
                foreach (DataRow row in table.Rows)
                    instances.Add(new SleepLog_db
                            (
                                id: Convert.ToInt32(row["clientID"]),
                                date: Convert.ToDateTime(row["date"]),
                                time: TimeSpan.Parse(row["time"].ToString()),
                                sleepDuration: Convert.ToInt32(row["duration"])
                            )
                        );

                // Return value
                statusResponse = new StatusResponse("Cardio Log list has been retrieved successfully.");
                return instances;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        /// <summary>
        /// Retrieves a single instance.
        /// </summary>
        public static List<SleepLog_db> Get(int id, DateTime date, TimeSpan time,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Get from database
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText: "SELECT * FROM cardio_log WHERE clientID = @id, date = @date, time = @time",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id },
                            { "@date", date },
                            { "@time", time },
                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                // Parse data
                List<SleepLog_db> instances = new List<SleepLog_db>();
                foreach (DataRow row in table.Rows)
                    instances.Add(new SleepLog_db
                            (
                                id: Convert.ToInt32(row["clientID"]),
                                date: Convert.ToDateTime(row["date"]),
                                time: TimeSpan.Parse(row["time"].ToString()),
                                sleepDuration: Convert.ToInt32(row["duration"])
                            )
                        );

                // Return value
                statusResponse = new StatusResponse("Cardio Log list has been retrieved successfully.");
                return instances;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        /// <summary>
        /// Deletes an instance.
        /// </summary>
        public static bool Delete(int id, DateTime date, TimeSpan time,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Get from database
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText:
                        "DELETE FROM cardio_log WHERE clientID = @id, date = @date, time = @time",

                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id },
                            { "@date", date },
                            { "@time", time },
                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("Cardio Log has been deleted successfully.");
                return true;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return false;
            }
        }

        /// <summary>
        /// Adds a new instance into the database.
        /// </summary>
        public static bool Edit(int id, DateTime date, TimeSpan time, int duration,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Validate
                if (id == 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid id.");
                if (date == DateTime.MinValue)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid date.");
                if (time == TimeSpan.Zero)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a type.");
                if (duration == 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide the number of calories burned.");

                // Add to database
                int rowsAffected = context.ExecuteNonQueryCommand
                    (
                        commandText:
                        "UPDATE sleep_log duration = @duration WHERE clientID = @id, date = @date, time = @time",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id },
                            { "@date", date },
                            { "@time", time },
                            { "@duration", duration },
                        },
                        message: out string message
                    );
                if (rowsAffected == -1)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("Cardio Log edited successfully");
                return true;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return false;
            }
        }
    }
}
