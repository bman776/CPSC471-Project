﻿using DatabaseLibrary.Core;
using DatabaseLibrary.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Net;
using System.Text;

namespace DatabaseLibrary.Helpers
{
    public class ExerciseSetHelper_db
    {
        public static ExerciseSet_db Add(int id, DateTime date, TimeSpan time, int weight, string type, int reps, int setNumber,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                if (id == 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid id.");
                if (date == DateTime.MinValue)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid date.");
                if (time == TimeSpan.Zero)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid time.");
                if (weight == 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a weight.");
                if (string.IsNullOrEmpty(type?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide an exercise type.");
                if (reps == 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide number of reps.");
                if (setNumber == 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide set number.");

                ExerciseSet_db instance = new ExerciseSet_db
                (
                    id, date, time, weight, type, reps, setNumber

                );

                int rowsAffected = context.ExecuteNonQueryCommand
                    (
                        commandText:
                        "INSERT INTO exercise_set (clientID, workoutLog_date, workoutLog_time, type, set_number, reps, weight) values (@id, @date, @time, @type, @set_number, @reps, @weight)",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", instance.Id },
                            { "@date", instance.LogDate },
                            { "@time", instance.LogTime },
                            { "@type", instance.Type },
                            { "@set_number", instance.SetNumber },
                            { "@reps", instance.Reps },
                            { "@weight", instance.Weight }

                        },
                        message: out string message
                    );
                if (rowsAffected == -1)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("exercise set added successfully");
                return instance;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        public static List<ExerciseSet_db> GetCollection(int id,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Get from database
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText: "SELECT * FROM exercise_set WHERE clientID = @id",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id }
                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                // Parse data
                List<ExerciseSet_db> instances = new List<ExerciseSet_db>();
                foreach (DataRow row in table.Rows)
                    instances.Add(new ExerciseSet_db
                            (
                                id: Convert.ToInt32(row["clientID"]),
                                date: Convert.ToDateTime(row["workoutLog_date"]),
                                time: TimeSpan.Parse(row["workoutLog_time"].ToString()),
                                type: row["type"].ToString(),
                                setNumber: Convert.ToInt32(row["set_number"]),
                                reps: Convert.ToInt32(row["reps"]),
                                weight: Convert.ToInt32(row["weight"])
                            )
                        );

                // Return value
                statusResponse = new StatusResponse("Exercise Set list has been retrieved successfully.");
                return instances;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        public static List<ExerciseSet_db> Get(int id, DateTime date, TimeSpan time,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Get from database
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText: "SELECT * FROM exercise_set WHERE clientID = @id, workoutLog_date = @date, workoutLog_time = @time",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id },
                            { "@date", date },
                            { "@time", time }
                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                // Parse data
                List<ExerciseSet_db> instances = new List<ExerciseSet_db>();
                foreach (DataRow row in table.Rows)
                    instances.Add(new ExerciseSet_db
                            (
                                id: Convert.ToInt32(row["clientID"]),
                                date: Convert.ToDateTime(row["workoutLog_date"]),
                                time: TimeSpan.Parse(row["workoutLog_time"].ToString()),
                                type: row["type"].ToString(),
                                setNumber: Convert.ToInt32(row["set_number"]),
                                reps: Convert.ToInt32(row["reps"]),
                                weight: Convert.ToInt32(row["weight"])
                            )
                        );

                // Return value
                statusResponse = new StatusResponse("Exercise Set list has been retrieved successfully.");
                return instances;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        /// <summary>
        /// Deletes an instance.
        /// </summary>
        public static bool Delete(int id, DateTime date, TimeSpan time,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Get from database
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText:
                        "DELETE FROM exercise_set WHERE clientID = @id, workoutLog_date = @date, workoutLog_time = @time",

                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id },
                            { "@date", date },
                            { "@time", time }
                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("Exercise Set has been deleted successfully.");
                return true;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return false;
            }
        }

        /// <summary>
        /// Adds a new instance into the database.
        /// </summary>
        public static bool Edit(int id, DateTime date, TimeSpan time, int weight, string type, int reps, int setNumber,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Validate
                if (id == 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid id.");
                if (date == DateTime.MinValue)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid date.");
                if (time == TimeSpan.Zero)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid time.");
                if (weight == 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a weight.");
                if (string.IsNullOrEmpty(type?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide an exercise type.");
                if (reps == 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide number of reps.");
                if (setNumber == 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide set number.");

                // Add to database
                int rowsAffected = context.ExecuteNonQueryCommand
                    (
                        commandText:
                        "UPDATE exercise_set weight = @weight, type = @type, set_number = @sets, reps = @reps WHERE clientID = @id, workoutLog_date = @date, workoutLog_time = @time",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id },
                            { "@date", date },
                            { "@time", time },
                            { "@type", type },
                            { "@set_number", setNumber },
                            { "@reps", reps },
                            { "@weight", weight }
                        },
                        message: out string message
                    );
                if (rowsAffected == -1)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("Exercise Set edited successfully");
                return true;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return false;
            }
        }
    }
}
