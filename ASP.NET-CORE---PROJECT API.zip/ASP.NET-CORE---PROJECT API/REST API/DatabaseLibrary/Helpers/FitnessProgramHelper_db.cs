﻿using DatabaseLibrary.Core;
using DatabaseLibrary.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Net;
using System.Text;

namespace DatabaseLibrary.Helpers
{
    public class FitnessProgramHelper_db
    {

        public static FitnessProgram_db Add(int id, string name, string description, string routine, DateTime creationDate, string video, string type, string modality,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                if (id == 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide an id.");
                if (string.IsNullOrEmpty(name?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a name.");
                if (string.IsNullOrEmpty(description?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a description.");
                if (string.IsNullOrEmpty(routine?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a routine.");
                if (creationDate == DateTime.MinValue)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid date.");

                FitnessProgram_db instance = new FitnessProgram_db
                    (
                        id, name, description, routine, creationDate, video, type, modality
                    );

                // Add to database
                int rowsAffected = context.ExecuteNonQueryCommand
                    (
                        commandText: "INSERT INTO fitness_prgrm (instructor_authorID, name, description, creation_date, routine, inst_vid, training_type, exercise_modality) values (@id, @name, @description, @date, @routine, @video, @type, @modality)",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", instance.Id },
                            { "@name", instance.Name },
                            { "@description", instance.Description },
                            { "@date", instance.CreationDate },
                            { "@routine", instance.Routine },
                            { "@video", instance.Video },
                            { "@type", instance.Type },
                            { "@modality", instance.Modality }
                        },
                        message: out string message
                    );
                if (rowsAffected == -1)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("Fitness Program has been retrieved successfully.");
                return instance;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        public static List<FitnessProgram_db> GetCollection(int id,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText: "SELECT * FROM fitness_prgrm WHERE instructor_authorID = @id",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id }
                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                List<FitnessProgram_db> instances = new List<FitnessProgram_db>();
                foreach (DataRow row in table.Rows)
                    instances.Add(new FitnessProgram_db
                            (
                                id: Convert.ToInt32(row["instructor_authorID"]),
                                name: row["name"].ToString(),
                                description: row["description"].ToString(),
                                creationDate: Convert.ToDateTime(row["creation_date"]),
                                routine: row["routine"].ToString(),
                                video: row["video"].ToString(),
                                type: row["type"].ToString(),
                                modality: row["modality"].ToString()
                            )
                        );

                // Return value
                statusResponse = new StatusResponse("Fitness Programs list has been retrieved successfully.");
                return instances;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        public static List<FitnessProgram_db> Get(int id, string name,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText: "SELECT * FROM fitness_prgrm WHERE instructor_authorID = @id, name = @name",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id },
                            { "@name", name }
                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                List<FitnessProgram_db> instances = new List<FitnessProgram_db>();
                foreach (DataRow row in table.Rows)
                    instances.Add(new FitnessProgram_db
                            (
                                id: Convert.ToInt32(row["instructor_authorID"]),
                                name: row["name"].ToString(),
                                description: row["description"].ToString(),
                                creationDate: Convert.ToDateTime(row["creation_date"]),
                                routine: row["routine"].ToString(),
                                video: row["video"].ToString(),
                                type: row["type"].ToString(),
                                modality: row["modality"].ToString()
                            )
                        );

                // Return value
                statusResponse = new StatusResponse("Fitness Program has been retrieved successfully.");
                return instances;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        /// <summary>
        /// Deletes an instance.
        /// </summary>
        public static bool Delete(int id, string name,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Get from database
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText: "DELETE FROM fitness_prgrm WHERE instructor_authorID = @id, name = @name",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id },
                            { "@name", name }
                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("Fitness Program has been deleted successfully.");
                return true;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return false;
            }
        }

        public static bool Edit(int id, string name, string description, string routine, DateTime creationDate, string video, string type, string modality,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Validate
                if (id == 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide an id.");
                if (string.IsNullOrEmpty(name?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a name.");
                if (string.IsNullOrEmpty(description?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a description.");
                if (string.IsNullOrEmpty(routine?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a routine.");
                if (creationDate == DateTime.MinValue)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid date.");

                // Add to database
                int rowsAffected = context.ExecuteNonQueryCommand
                    (
                        commandText: "UPDATE fitness_prgrm instructor_authorID = @id, name = @name, description = @description, creation_date = @date, routine = @routine, inst_video = @video, training_type = @type, exercise_modality = @modality",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id },
                            { "@name", name },
                            { "@description", description },
                            { "@date", creationDate },
                            { "@routine", routine },
                            { "@video", video },
                            { "@type", type },
                            { "@modality", modality }
                        },
                        message: out string message
                    );
                if (rowsAffected == -1)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("Client edited successfully");
                return true;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return false;
            }
        }
    }
}
