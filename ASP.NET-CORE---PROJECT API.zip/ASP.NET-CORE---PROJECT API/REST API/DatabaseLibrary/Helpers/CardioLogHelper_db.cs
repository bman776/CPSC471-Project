﻿using DatabaseLibrary.Core;
using DatabaseLibrary.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Net;
using System.Text;

namespace DatabaseLibrary.Helpers
{
    public class CardioLogHelper_db
    {

        /// <summary>
        /// Adds a new instance into the database.
        /// </summary>
        public static CardioLog_db Add(int id, string name, DateTime date, string type, TimeSpan start, TimeSpan end, int calories,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                //Validate
                if (id == 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid id.");
                if (string.IsNullOrEmpty(name?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a log name.");
                if (date == DateTime.MinValue)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid date.");
                if (string.IsNullOrEmpty(type?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a type.");
                if (start == TimeSpan.Zero)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid time.");
                if (end == TimeSpan.Zero)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid time.");
                if (calories == 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide the number of calories burned.");

                CardioLog_db instance = new CardioLog_db
                    (
                        id, name, date, type, start, end, calories
                    );

                // Add to database
                int rowsAffected = context.ExecuteNonQueryCommand
                    (
                        commandText:
                        "INSERT INTO cardio_log (clientID, log_name, log_date, cardio_type, start_time, end_time, calories_burned) values (@id, @name, @date, @cardio, @type, @start, @end, @calories)",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", instance.ClientId },
                            { "@name", instance.LogName },
                            { "@date", instance.LogDate },
                            { "@type", instance.CardioType },
                            { "@start", instance.StartTime },
                            { "@end", instance.EndTime },
                            { "@calories", instance.CaloriesBurned }

                        },
                        message: out string message
                    );
                if (rowsAffected == -1)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("Cardio Log added successfully");
                return instance;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        /// <summary>
        /// Retrieves a list of instances.
        /// </summary>
        public static List<CardioLog_db> GetCollection(int id,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Get from database
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText: "SELECT * FROM cardio_log WHERE clientID = @id",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id }
                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                // Parse data
                List<CardioLog_db> instances = new List<CardioLog_db>();
                foreach (DataRow row in table.Rows)
                    instances.Add(new CardioLog_db
                            (
                                id: Convert.ToInt32(row["clientID"]),
                                logName: row["log_name"].ToString(),
                                logDate: Convert.ToDateTime(row["log_date"]),
                                cardioType: row["cardio_type"].ToString(),
                                startTime: TimeSpan.Parse(row["start_time"].ToString()),
                                endTime: TimeSpan.Parse(row["end_time"].ToString()),
                                caloriesBurned: Convert.ToInt32(row["calories_burned"])
                            )
                        );

                // Return value
                statusResponse = new StatusResponse("Cardio Log list has been retrieved successfully.");
                return instances;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        /// <summary>
        /// Retrieves a single instance.
        /// </summary>
        public static List<CardioLog_db> Get(int id, DateTime date, TimeSpan start,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Get from database
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText: "SELECT * FROM cardio_log WHERE clientID = @id, log_date = @date, start_time = @start",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id },
                            { "@date", date },
                            { "@start", start },
                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                // Parse data
                List<CardioLog_db> instances = new List<CardioLog_db>();
                foreach (DataRow row in table.Rows)
                    instances.Add(new CardioLog_db
                            (
                                id: Convert.ToInt32(row["clientID"]),
                                logName: row["log_name"].ToString(),
                                logDate: Convert.ToDateTime(row["log_date"]),
                                cardioType: row["cardio_type"].ToString(),
                                startTime: TimeSpan.Parse(row["start_time"].ToString()),
                                endTime: TimeSpan.Parse(row["end_time"].ToString()),
                                caloriesBurned: Convert.ToInt32(row["calories_burned"])
                            )
                        );

                // Return value
                statusResponse = new StatusResponse("Cardio Log list has been retrieved successfully.");
                return instances;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return null;
            }
        }

        /// <summary>
        /// Deletes an instance.
        /// </summary>
        public static bool Delete(int id, DateTime date, TimeSpan start,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Get from database
                DataTable table = context.ExecuteDataQueryCommand
                    (
                        commandText:
                        "DELETE FROM cardio_log WHERE clientID = @id, log_date = @date, start_time = @start",

                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id },
                            { "@date", date },
                            { "@start", start },
                        },
                        message: out string message
                    );
                if (table == null)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("Cardio Log has been deleted successfully.");
                return true;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return false;
            }
        }

        /// <summary>
        /// Adds a new instance into the database.
        /// </summary>
        public static bool Edit(int id, string name, DateTime date, string type, TimeSpan start, TimeSpan end, int calories,
            DbContext context, out StatusResponse statusResponse)
        {
            try
            {
                // Validate
                if (id == 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid id.");
                if (string.IsNullOrEmpty(name?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a log name.");
                if (date == DateTime.MinValue)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid date.");
                if (string.IsNullOrEmpty(type?.Trim()))
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a type.");
                if (start == TimeSpan.Zero)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid time.");
                if (end == TimeSpan.Zero)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide a valid time.");
                if (calories == 0)
                    throw new StatusException(HttpStatusCode.BadRequest, "Please provide the number of calories burned.");

                // Add to database
                int rowsAffected = context.ExecuteNonQueryCommand
                    (
                        commandText:
                        "UPDATE cardio_log log_name = @name, cardio_type = @type, end_time = @end, calories_burned = calories WHERE clientID = @id, log_date = @date, start_time = @time",
                        parameters: new Dictionary<string, object>()
                        {
                            { "@id", id },
                            { "@name", name },
                            { "@date", date },
                            { "@type", type },
                            { "@start", start },
                            { "@end", end },
                            { "@calories", calories }
                        },
                        message: out string message
                    );
                if (rowsAffected == -1)
                    throw new Exception(message);

                // Return value
                statusResponse = new StatusResponse("Cardio Log edited successfully");
                return true;
            }
            catch (Exception exception)
            {
                statusResponse = new StatusResponse(exception);
                return false;
            }
        }
    }
}
